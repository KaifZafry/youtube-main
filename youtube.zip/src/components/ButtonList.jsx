import React from 'react'
import Buttons from './Buttons'

const ButtonList = () => {
  return (
    <div className='text-center overflow-scroll ml-34 md:w-auto md:overflow-hidden w-[100vw]'>

        <Buttons/>
    </div>

    
  )
}

export default ButtonList